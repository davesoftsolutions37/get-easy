Thanks for downloading this theme!

Theme Name: Day
Theme URL: https://bootstrapmade.com/day-multipurpose-html-template-for-free/
Author: BootstrapMade
Author URL: https://bootstrapmade.com